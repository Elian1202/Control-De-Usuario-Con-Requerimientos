Create database SellPoint;

Use SellPoint;

Create table Entidades(
IdEntidad int identity(1,1) primary key,
Descripcion varchar(120) not null,
Direccion text not null,
Localidad varchar(40) not null,
TipoEntidad varchar(8) null default 'Juridica',
TipoDocumento varchar(9) null default 'RNC',
NumeroDocumento numeric(15) not null,
Tel�fonos varchar(60) not null,
URLPaginaWeb varchar(120),
URLFacebook varchar(120),
URLInstagram varchar(120),
URLTwitter varchar(120),
URLTikTok varchar(120),
IdGrupoEntidad int,
IdTipoEntidad int,
LimiteCredito numeric(10)null default 0,
Email varchar(60) not null,
UserNameEntidad varchar(60) not null,
PassworEntidad varchar(80) not null,
RolUserEntidad varchar(10) null default 'User',
Comentario text,
Status varchar(10) null default 'Activa',
NoEliminable bit null default 0,
FechaRegistro date not null default getdate(),

CONSTRAINT Fk_GrupoEntidad_Entidades
FOREIGN KEY (IdGrupoEntidad) REFERENCES GruposEntidades(IdGrupoEntidad)
  ON UPDATE CASCADE
  ON DELETE CASCADE,
CONSTRAINT Fk_TiposEntidades_Entidades
FOREIGN KEY (IdTipoEntidad) REFERENCES TiposEntidades(IdTipoEntidad)
  ON UPDATE CASCADE
  ON DELETE CASCADE
);



CREATE INDEX Entidades_IdEntidades
    ON Entidades (IdEntidad ASC,Descripcion ASC,TipoEntidad ASC, TipoDocumento ASC,
  NumeroDocumento ASC,IdGrupoEntidad ASC,IdTipoEntidad ASC);



insert into Entidades (Descripcion,Direccion,Localidad,NumeroDocumento, Tel�fonos, IdGrupoEntidad, IdTipoEntidad, Email,UserNameEntidad,PassworEntidad) 
values
('Admin','Calle 28, casa numero #68 ensanche espailla', 'Distrito nacional','40200000002', '8090004444',1,1, 'loquesea','Elian','c311f704de3d3bc0d3e6f71621adf634ff6b54dcee4898db2cd1d2e41c4f850c');


Create table GruposEntidades(
IdGrupoEntidad int identity(1,1) primary key,
Descripcion varchar(120)not null,
Comentario text,
Status varchar(10) null default 'Activa',
NoEliminable bit null default 0,
FechaRegistro date not null default getdate(),
);


CREATE INDEX GruposEntidades_Sellpoint
   ON GruposEntidades (IdGrupoEntidad ASC, Descripcion ASC);


insert into GruposEntidades (Descripcion)
values
('Grupo de entidad 1');



Create table TiposEntidades(
IdTipoEntidad int identity(1,1) primary key,
Descripcion varchar(120)not null,
IdGrupoEntidad int not null,
Comentario text,
Status varchar(10)null default 'Activa',
NoEliminable bit null default 0,
FechaRegistro date not null default getdate(),
);

CREATE INDEX TiposEntidades_Sellpoint
  ON TiposEntidades (IdTipoEntidad ASC, Descripcion ASC,IdGrupoEntidad ASC);


  
insert into TiposEntidades(Descripcion, IdGrupoEntidad) 
values 
('Tipo de entidad 1', 1);



CREATE VIEW v_TiposEntidades
AS
SELECT
te.IdTipoEntidad AS ID,
te.Descripcion AS Entidad,
ge.Descripcion AS [Grupo al que pertenece],
te.Comentario,
te.Status AS Estado,
te.FechaRegistro AS [Fecha de registro]
FROM TiposEntidades te
INNER JOIN GruposEntidades ge ON ge.IdGrupoEntidad = te.IdGrupoEntidad;



SELECT * FROM v_TiposEntidades;



 SELECT * FROM GruposEntidades;


 SELECT * FROM TiposEntidades;


 SELECT * FROM Entidades;


 DBCC CHECKIDENT(GruposEntidades, RESEED, 0)
