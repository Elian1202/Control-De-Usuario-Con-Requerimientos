﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicacionSellpoint_v1._0.CodigoFuente
{
    public class UsuarioActual
    {
        public static int IdEntidad { get; set; }
        public static string Descripcion { get; set; }
        public static int IdGrupoEntidad { get; set; }
    }
}
