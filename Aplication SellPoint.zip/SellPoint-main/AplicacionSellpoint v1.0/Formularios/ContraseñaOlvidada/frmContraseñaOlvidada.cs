﻿using AplicacionSellpoint_v1._0.CodigoFuente;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionSellpoint_v1._0.Formularios.ContraseñaOlvidada
{
    public partial class frmContraseñaOlvidada : Form
    {

        Random random = new Random();
        public int generatecode;

        public frmContraseñaOlvidada()
        {
            InitializeComponent();
        }

        Encrypt sha256 = new Encrypt();

        private void SendEmail()
        {
            generatecode = random.Next(123123, 999999);

            string emailOrigin = "";
            string passwordEmail = "";



            string BodyMail =

                @"<!DOCTYPE html>
                                <html lang='en'>
                                  <head>
                                      <meta charset='UTF - 8' />
                                  </head>
                                  <body style='height: 900px;'>
                                      <div style='margin: 0 auto;
                                                background-color: #f7f7f7; 
                                                border: 1px solid #0070ba; 
                                                border-radius: 10px;
                                                width: 480px;
                                                height: 720px;
                                                padding-top:20px;'>
        
                                          <header>
                                             <img src='https://i.ibb.co/kBSVQgW/Shield-Login-Test.jpg'
                                                alt='Login Test Logo'
                                                style='
                                                  padding-left:140px;
                                                  padding-right:138px;
                                                  background-color: white;
                                                  height:180px;
                                                  width:200px;'/>
                                          </header>

                                          <div>
                                            <h1 style='color: #0070ba; 
                                                margin-left: 20px;
                                                font-family:sans-serif;
                                                margin-bottom: 50px;'>Reset password<h1>
                                          </div>


                                          <p style='font-family:sans-serif; 
                                                    color:black;
                                                    text-align: left;
                                                    margin-left: 20px;
                                                    margin-bottom: 50px;'>
                                                    We received a request to reset your password.<br><br>
                                                    Enter the following code to reset the password:
                                               </p>

                                          <div>
                                            <h2 style='font-family: sans-serif;
                                                       margin-left: 20px;
                                                       margin-bottom: 5px;
                                                       font-size: 35px;'>Code: </h2>
                                            <br/>

                                               <h2 style='font-family: sans-serif;
                                                           text-align: center;
                                                           color: #10b6f8;
                                                           font-size: 35px;
                                                           margin-bottom: 80px;'>" + generatecode + @"</h2>
                                          </div>

                                             <img src='https://i.ibb.co/0tH8PpH/Login-Test.jpg'
                                                alt='Login Test Banner'
                                                style='
                                                  border: 2px solid #0070ba; 
                                                  border-radius: 10px;
                                                  height:120px;
                                                  width:477px;
                                                  margin-right: 65px;'/>
                                        </div>
                                      </div>                                                                                                   
                                        <p style='color: black; 
                                                  font-family:sans-serif;
                                                  text-align: center;'>Login Test Copyright &copy; 2022</p>
                                    </div>
                                  </body>
                                </html>";

            string destinationEmail = txtForgetPassEmail.Text.Trim();

            MailMessage Message = new MailMessage(emailOrigin, destinationEmail, "Cambiar contraseña", BodyMail);

            Message.IsBodyHtml = true;

            SmtpClient SenDMail = new SmtpClient("smtp.gmail.com");
            SenDMail.EnableSsl = true;
            SenDMail.UseDefaultCredentials = false;
            SenDMail.Port = 587;
            SenDMail.Credentials = new System.Net.NetworkCredential(emailOrigin, passwordEmail);
            SenDMail.Send(Message);
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            eProvider.Clear();
            if (txtEnterNewPassword.Text.Trim().Length == 0)
            {
                eProvider.SetError(txtEnterNewPassword, "Debe ingresar la nueva contraseña!");
                txtEnterNewPassword.Focus();
                return;
            }

            if (txtConfirmNewPassword.Text.Trim().Length == 0)
            {
                eProvider.SetError(txtConfirmNewPassword, "Ingrese la misma contraseña nuevamente!");
                txtConfirmNewPassword.Focus();
                return;
            }

            if (txtEnterNewPassword.Text.Trim() != txtConfirmNewPassword.Text.Trim())
            {
                eProvider.SetError(txtConfirmNewPassword, "La contraseña ingresada no coincide con la anterior!");
                txtConfirmNewPassword.Focus();
                return;
            }

            if (txtEnterNewPassword.Text.Trim() == txtConfirmNewPassword.Text.Trim())
            {

                string encryptpass = sha256.GetSHA256(txtConfirmNewPassword.Text.Trim());

                string query = "UPDATE Entidades SET PassworEntidad = '" + encryptpass + "' WHERE Email = '" + txtForgetPassEmail.Text.Trim() + "'";
                bool result = AccesoABaseDeDatos.Actualizar(query);
                if (result)
                {
                    MessageBox.Show("Contraseña cambiada exitosamente!");
                    this.Close();
                    return;
                }
                else
                {
                    MessageBox.Show("Ha ocurrido un error inesperado. Por favor contactese con el programador.");
                }
            }
            else
            {
                MessageBox.Show("La contraseña ingresada no coincide con la anterior!");
            }
        }

        private void btnSendEmail_Click(object sender, EventArgs e)
        {
            eProvider.Clear();

            if (txtForgetPassEmail.Text.Trim().Length == 0)
            {
                eProvider.SetError(txtForgetPassEmail, "Debe ingresar el correo electrónico!");
                txtForgetPassEmail.Focus();
                return;
            }

            DataTable datatable = AccesoABaseDeDatos.Seleccionar("SELECT Email FROM Entidades WHERE Email = '" + txtForgetPassEmail.Text.Trim() + "'");
            if (datatable != null)
            {
                if (datatable.Rows.Count > 0)
                {
                    lblStep1.Visible = true;
                    CheckerStep1.Visible = true;
                    txtEnterCode.Enabled = true;
                    btnNextStep.Enabled = true;
                    btnSendAgain.Enabled = true;
                    btnSendEmail.Enabled = false;
                    lblErrorEmail.Visible = false;

                    SendEmail();
                    MessageBox.Show("El correo se envió exitosamente!");
                }

                else
                {
                    lblErrorEmail.Visible = true;
                }
            }
        }

        private void btnNextStep_Click(object sender, EventArgs e)
        {
            eProvider.Clear();

            if (txtEnterCode.Text.Trim().Length == 0)
            {
                eProvider.SetError(txtEnterCode, "Ingrese el código!");
                txtEnterCode.Focus();
                return;
            }

            if (generatecode.ToString() == txtEnterCode.Text.Trim())
            {
                lblStep2.Visible = true;
                CheckerStep2.Visible = true;
                txtEnterNewPassword.Enabled = true;
                txtConfirmNewPassword.Enabled = true;
                btnChangePassword.Enabled = true;
                btnNextStep.Enabled = false;
                btnSendAgain.Enabled = false;
                MessageBox.Show("Código correcto!");
            }
            else
            {
                MessageBox.Show("El código ingresado no coincide!");
            }
        }

        private void btnSendAgain_Click(object sender, EventArgs e)
        {
            SendEmail();
            MessageBox.Show("El correo fue enviado nuevamente!");
        }

        private void txtEnterCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}