﻿namespace AplicacionSellpoint_v1._0.Formularios.ContraseñaOlvidada
{
    partial class frmContraseñaOlvidada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmContraseñaOlvidada));
            this.eProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnChangePassword = new System.Windows.Forms.Button();
            this.txtConfirmNewPassword = new System.Windows.Forms.TextBox();
            this.txtEnterNewPassword = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.CheckerStep2 = new System.Windows.Forms.Button();
            this.lblStep2 = new System.Windows.Forms.Label();
            this.btnSendAgain = new System.Windows.Forms.Button();
            this.btnNextStep = new System.Windows.Forms.Button();
            this.txtEnterCode = new System.Windows.Forms.TextBox();
            this.CheckerStep1 = new System.Windows.Forms.Button();
            this.lblStep1 = new System.Windows.Forms.Label();
            this.btnSendEmail = new System.Windows.Forms.Button();
            this.lblErrorEmail = new System.Windows.Forms.Label();
            this.txtForgetPassEmail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblHeader = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.eProvider)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // eProvider
            // 
            this.eProvider.ContainerControl = this;
            // 
            // btnChangePassword
            // 
            this.btnChangePassword.Enabled = false;
            this.btnChangePassword.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnChangePassword.Location = new System.Drawing.Point(185, 543);
            this.btnChangePassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnChangePassword.Name = "btnChangePassword";
            this.btnChangePassword.Size = new System.Drawing.Size(119, 33);
            this.btnChangePassword.TabIndex = 32;
            this.btnChangePassword.Text = "Cambiar";
            this.btnChangePassword.UseVisualStyleBackColor = true;
            this.btnChangePassword.Click += new System.EventHandler(this.btnChangePassword_Click);
            // 
            // txtConfirmNewPassword
            // 
            this.txtConfirmNewPassword.Enabled = false;
            this.txtConfirmNewPassword.Location = new System.Drawing.Point(196, 486);
            this.txtConfirmNewPassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtConfirmNewPassword.Name = "txtConfirmNewPassword";
            this.txtConfirmNewPassword.PasswordChar = '*';
            this.txtConfirmNewPassword.Size = new System.Drawing.Size(255, 23);
            this.txtConfirmNewPassword.TabIndex = 31;
            // 
            // txtEnterNewPassword
            // 
            this.txtEnterNewPassword.Enabled = false;
            this.txtEnterNewPassword.Location = new System.Drawing.Point(181, 432);
            this.txtEnterNewPassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtEnterNewPassword.Name = "txtEnterNewPassword";
            this.txtEnterNewPassword.PasswordChar = '*';
            this.txtEnterNewPassword.Size = new System.Drawing.Size(270, 23);
            this.txtEnterNewPassword.TabIndex = 30;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(22, 484);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 21);
            this.label4.TabIndex = 42;
            this.label4.Text = "Confirmar contraseña: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(22, 432);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(142, 21);
            this.label3.TabIndex = 41;
            this.label3.Text = "Nueva contraseña: ";
            // 
            // CheckerStep2
            // 
            this.CheckerStep2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CheckerStep2.Image = ((System.Drawing.Image)(resources.GetObject("CheckerStep2.Image")));
            this.CheckerStep2.Location = new System.Drawing.Point(151, 370);
            this.CheckerStep2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CheckerStep2.Name = "CheckerStep2";
            this.CheckerStep2.Size = new System.Drawing.Size(30, 22);
            this.CheckerStep2.TabIndex = 40;
            this.CheckerStep2.UseVisualStyleBackColor = true;
            this.CheckerStep2.Visible = false;
            // 
            // lblStep2
            // 
            this.lblStep2.AutoSize = true;
            this.lblStep2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblStep2.Location = new System.Drawing.Point(22, 369);
            this.lblStep2.Name = "lblStep2";
            this.lblStep2.Size = new System.Drawing.Size(123, 21);
            this.lblStep2.TabIndex = 39;
            this.lblStep2.Text = "Siguiente paso";
            this.lblStep2.Visible = false;
            // 
            // btnSendAgain
            // 
            this.btnSendAgain.Enabled = false;
            this.btnSendAgain.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSendAgain.Location = new System.Drawing.Point(306, 305);
            this.btnSendAgain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSendAgain.Name = "btnSendAgain";
            this.btnSendAgain.Size = new System.Drawing.Size(145, 33);
            this.btnSendAgain.TabIndex = 29;
            this.btnSendAgain.Text = "Enviar nuevamente";
            this.btnSendAgain.UseVisualStyleBackColor = true;
            this.btnSendAgain.Click += new System.EventHandler(this.btnSendAgain_Click);
            // 
            // btnNextStep
            // 
            this.btnNextStep.Enabled = false;
            this.btnNextStep.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnNextStep.Location = new System.Drawing.Point(181, 305);
            this.btnNextStep.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNextStep.Name = "btnNextStep";
            this.btnNextStep.Size = new System.Drawing.Size(119, 33);
            this.btnNextStep.TabIndex = 28;
            this.btnNextStep.Text = "Siguiente paso";
            this.btnNextStep.UseVisualStyleBackColor = true;
            this.btnNextStep.Click += new System.EventHandler(this.btnNextStep_Click);
            // 
            // txtEnterCode
            // 
            this.txtEnterCode.Enabled = false;
            this.txtEnterCode.Location = new System.Drawing.Point(181, 269);
            this.txtEnterCode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtEnterCode.Name = "txtEnterCode";
            this.txtEnterCode.Size = new System.Drawing.Size(270, 23);
            this.txtEnterCode.TabIndex = 27;
            this.txtEnterCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEnterCode_KeyPress);
            // 
            // CheckerStep1
            // 
            this.CheckerStep1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CheckerStep1.Image = ((System.Drawing.Image)(resources.GetObject("CheckerStep1.Image")));
            this.CheckerStep1.Location = new System.Drawing.Point(151, 208);
            this.CheckerStep1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CheckerStep1.Name = "CheckerStep1";
            this.CheckerStep1.Size = new System.Drawing.Size(30, 22);
            this.CheckerStep1.TabIndex = 37;
            this.CheckerStep1.UseVisualStyleBackColor = true;
            this.CheckerStep1.Visible = false;
            // 
            // lblStep1
            // 
            this.lblStep1.AutoSize = true;
            this.lblStep1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblStep1.Location = new System.Drawing.Point(22, 206);
            this.lblStep1.Name = "lblStep1";
            this.lblStep1.Size = new System.Drawing.Size(123, 21);
            this.lblStep1.TabIndex = 36;
            this.lblStep1.Text = "Siguiente paso";
            this.lblStep1.Visible = false;
            // 
            // btnSendEmail
            // 
            this.btnSendEmail.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSendEmail.Location = new System.Drawing.Point(240, 148);
            this.btnSendEmail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSendEmail.Name = "btnSendEmail";
            this.btnSendEmail.Size = new System.Drawing.Size(142, 36);
            this.btnSendEmail.TabIndex = 26;
            this.btnSendEmail.Text = "Enviar correo";
            this.btnSendEmail.UseVisualStyleBackColor = true;
            this.btnSendEmail.Click += new System.EventHandler(this.btnSendEmail_Click);
            // 
            // lblErrorEmail
            // 
            this.lblErrorEmail.AutoSize = true;
            this.lblErrorEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblErrorEmail.ForeColor = System.Drawing.Color.Red;
            this.lblErrorEmail.Location = new System.Drawing.Point(167, 128);
            this.lblErrorEmail.Name = "lblErrorEmail";
            this.lblErrorEmail.Size = new System.Drawing.Size(309, 17);
            this.lblErrorEmail.TabIndex = 35;
            this.lblErrorEmail.Text = "No hay cuentas vinculadas a este correo!";
            this.lblErrorEmail.Visible = false;
            // 
            // txtForgetPassEmail
            // 
            this.txtForgetPassEmail.Location = new System.Drawing.Point(181, 100);
            this.txtForgetPassEmail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtForgetPassEmail.Name = "txtForgetPassEmail";
            this.txtForgetPassEmail.Size = new System.Drawing.Size(270, 23);
            this.txtForgetPassEmail.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(22, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 21);
            this.label2.TabIndex = 34;
            this.label2.Text = "Ingresar correo: ";
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblHeader.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblHeader.Location = new System.Drawing.Point(102, 12);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(321, 46);
            this.lblHeader.TabIndex = 8;
            this.lblHeader.Text = "Olvidar contraseña";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(22, 266);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 21);
            this.label1.TabIndex = 38;
            this.label1.Text = "Ingresar código: ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel1.Controls.Add(this.lblHeader);
            this.panel1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Location = new System.Drawing.Point(-5, -3);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(527, 71);
            this.panel1.TabIndex = 33;
            // 
            // frmContraseñaOlvidada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 594);
            this.Controls.Add(this.btnChangePassword);
            this.Controls.Add(this.txtConfirmNewPassword);
            this.Controls.Add(this.txtEnterNewPassword);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CheckerStep2);
            this.Controls.Add(this.lblStep2);
            this.Controls.Add(this.btnSendAgain);
            this.Controls.Add(this.btnNextStep);
            this.Controls.Add(this.txtEnterCode);
            this.Controls.Add(this.CheckerStep1);
            this.Controls.Add(this.lblStep1);
            this.Controls.Add(this.btnSendEmail);
            this.Controls.Add(this.lblErrorEmail);
            this.Controls.Add(this.txtForgetPassEmail);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "frmContraseñaOlvidada";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Olvidar contraseña";
            ((System.ComponentModel.ISupportInitialize)(this.eProvider)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ErrorProvider eProvider;
        private System.Windows.Forms.Button btnChangePassword;
        private System.Windows.Forms.TextBox txtConfirmNewPassword;
        private System.Windows.Forms.TextBox txtEnterNewPassword;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button CheckerStep2;
        private System.Windows.Forms.Label lblStep2;
        private System.Windows.Forms.Button btnSendAgain;
        private System.Windows.Forms.Button btnNextStep;
        private System.Windows.Forms.TextBox txtEnterCode;
        private System.Windows.Forms.Button CheckerStep1;
        private System.Windows.Forms.Label lblStep1;
        private System.Windows.Forms.Button btnSendEmail;
        private System.Windows.Forms.Label lblErrorEmail;
        private System.Windows.Forms.TextBox txtForgetPassEmail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblHeader;
    }
}