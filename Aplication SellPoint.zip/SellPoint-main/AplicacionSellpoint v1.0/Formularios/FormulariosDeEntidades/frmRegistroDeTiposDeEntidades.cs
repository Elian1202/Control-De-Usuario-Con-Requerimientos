﻿using AplicacionSellpoint_v1._0.CodigoFuente;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionSellpoint_v1._0.Formularios.FormulariosDeEntidades
{
    public partial class frmRegistroDeTiposDeEntidades : Form
    {
        public frmRegistroDeTiposDeEntidades()
        {
            InitializeComponent();
            
        }

        public void LlenarCuadro(string busqueda_a_realizar)
        {
            string query = string.Empty;
            DataTable tabladedatos = new DataTable();
            if (string.IsNullOrEmpty(busqueda_a_realizar) && string.IsNullOrWhiteSpace(busqueda_a_realizar))
            {
                query = "SELECT * FROM v_TiposEntidades";
            }
            else
            {
                query = "SELECT * FROM v_TiposEntidades WHERE (Entidad +' '+ [Grupo al que pertenece] +' '+ Estado) LIKE '%" + busqueda_a_realizar + "%'";
            }
            
            tabladedatos = AccesoABaseDeDatos.Seleccionar(query);
            if (tabladedatos != null)
            {
                if (tabladedatos.Rows.Count > 0)
                {
                    dgvTEntidades.DataSource = tabladedatos;
                    dgvTEntidades.Columns[0].Width = 50;     // ID TipoEntidad.
                    dgvTEntidades.Columns[1].Width = 150;    // Descripcion.
                    dgvTEntidades.Columns[2].Width = 100;    // IdGrupoEntidad.
                    dgvTEntidades.Columns[3].Width = 120;    // Comentario.
                    dgvTEntidades.Columns[4].Width = 100;    // Estado.
                    dgvTEntidades.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;  // Fecha de registro.
                }
                else
                {
                    dgvTEntidades.DataSource = null;
                }
            }
            else
            {
                dgvTEntidades.DataSource = null;
            }
            
        }
    

        private void frmRegistroDeTiposDeEntidades_Load(object sender, EventArgs e)
        {
            ComboDeAyuda.LlenarGrupoDeEntidad(comboSeleccionarGrupoDeEntidad);
            btnRefrescar_Click(sender, e);
            LlenarCuadro("");

        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            ComboDeAyuda.LlenarGrupoDeEntidad(comboSeleccionarGrupoDeEntidad);
        }

        private void btnAgregarGrupo_Click(object sender, EventArgs e)
        {
            frmAgregarGrupoDeEntidades frm = new frmAgregarGrupoDeEntidades();
            frm.ShowDialog();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            errorP.Clear();
            if (comboSeleccionarGrupoDeEntidad.SelectedIndex == 0)
            {
                errorP.SetError(comboSeleccionarGrupoDeEntidad, "Debe seleccionar grupo de entidad.");
                comboSeleccionarGrupoDeEntidad.Focus();
                return;
            }

            if (textTipoDeEntidad.Text.Trim().Length == 0)
            {
                errorP.SetError(textTipoDeEntidad, "Debe ingresar el tipo de entidad.");
                textTipoDeEntidad.Focus();
                return;
            }

            DataTable tabla_de_datos = AccesoABaseDeDatos.Seleccionar("SELECT * FROM TiposEntidades WHERE Descripcion = '" + textTipoDeEntidad.Text.Trim() + "' AND IdGrupoEntidad = '" + comboSeleccionarGrupoDeEntidad.SelectedValue + "'");
            if (tabla_de_datos != null)
            {
                if (tabla_de_datos.Rows.Count > 0)
                {
                    errorP.SetError(textTipoDeEntidad, "Ya existe.");
                    textTipoDeEntidad.Focus();
                    return;
                }
            }
            int X = 0;
            if (chkN0_Eliminable.Checked)
            {
                X += 1;
            }

            String S = "Inactivo";

            if (chkStatus.Checked)
            {
                S = "Activo";
            }
            string query = string.Format("INSERT INTO TiposEntidades( Descripcion, IdGrupoEntidad,Comentario,Status,NoEliminable,FechaRegistro) VALUES('{0}',{1},'{2}','{3}',{4},'{5}')",
                textTipoDeEntidad.Text.Trim(), comboSeleccionarGrupoDeEntidad.SelectedValue,textBox1.Text.Trim(),S,X,DTFecha.Value.ToString("yyy/MM/dd"));
            bool resultado = AccesoABaseDeDatos.Insertar(query);
            if (resultado)
            {
                MessageBox.Show("Guardado exitosamente.");
                textTipoDeEntidad.Clear();
                comboSeleccionarGrupoDeEntidad.SelectedIndex = 0;
                LlenarCuadro("");
            }
            else
            {
                MessageBox.Show("Ha ocurrido un error inesperado. Por favor contactese con el programador.");
            }
        }

        private void dgvTEntidades_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBusqueda_TextChanged(object sender, EventArgs e)
        {
            LlenarCuadro(textBusqueda.Text.Trim());
        }
    }
}