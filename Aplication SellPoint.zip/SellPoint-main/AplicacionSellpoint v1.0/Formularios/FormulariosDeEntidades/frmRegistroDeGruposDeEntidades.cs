﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicacionSellpoint_v1._0.Formularios.FormulariosDeEntidades
{
    public partial class frmRegistroDeGruposDeEntidades : Form
    {
        public frmRegistroDeGruposDeEntidades()
        {
            InitializeComponent();
        }
    }
}
